package com.selcuk.Adlogs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdlogsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdlogsApplication.class, args);
	}

}
