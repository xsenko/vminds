package com.selcuk.Adlogs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdlogsApplicationTests {

	@Test
	void contextLoads() {
	}

}
